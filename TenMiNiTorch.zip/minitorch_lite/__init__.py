from .tensor import Tensor, tensor
from .autograd import backward
from .nn import Module, Parameter, Linear, Sequential, ReLU, MSELoss
from .optim import SGD

# Exponer las funciones principales a nivel de paquete
__all__ = [
    'Tensor', 'tensor', 'backward',
    'Module', 'Parameter', 'Linear', 'Sequential', 'ReLU', 'MSELoss',
    'SGD'
]
