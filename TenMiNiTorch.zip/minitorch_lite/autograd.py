from .tensor import Tensor
import numpy as np

class Function:
    """
    Clase base para todas las operaciones de autograd.
    Cada subclase debe implementar forward y backward.
    """
    
    @staticmethod
    def forward(ctx, *args):
        """
        Realiza la operación hacia adelante.
        ctx se usa para guardar tensores u otros datos necesarios para el backward.
        """
        raise NotImplementedError
        
    @staticmethod
    def backward(ctx, grad_output):
        """
        Calcula el gradiente de la operación con respecto a sus entradas.
        Devuelve una tupla de gradientes, uno por cada entrada.
        """
        raise NotImplementedError
        
    @classmethod
    def apply(cls, *args):
        """
        Método de conveniencia para ejecutar la operación y construir el grafo.
        """
        # 1. Extraer los tensores de entrada y verificar si se requiere gradiente
        input_tensors = [t for t in args if isinstance(t, Tensor)]
        requires_grad = any(t.requires_grad for t in input_tensors)
        
        # 2. Crear el contexto para guardar datos
        ctx = Context()
        
        # 3. Ejecutar el forward
        output_data = cls.forward(ctx, *args)
        
        # 4. Crear el tensor de salida
        output_tensor = Tensor(output_data, requires_grad=requires_grad)
        
        # 5. Si se requiere gradiente, adjuntar la función de gradiente (esta clase)
        if requires_grad:
            ctx.parents = input_tensors
            output_tensor.grad_fn = (cls, ctx)
            
        return output_tensor

class Context:
    """
    Clase para almacenar datos necesarios para la retropropagación.
    """
    def __init__(self):
        self.parents = []
        
    def save_for_backward(self, *args):
        self.saved_tensors = args

# --- Implementación de Operaciones Básicas ---

class Add(Function):
    """
    Operación de suma: c = a + b
    Gradientes: dL/da = dL/dc * 1, dL/db = dL/dc * 1
    """
    @staticmethod
    def forward(ctx, a, b):
        # La suma de datos de NumPy
        if isinstance(b, Tensor):
            return a.data + b.data
        return a.data + b
        
    @staticmethod
    def backward(ctx, grad_output):
        # Los gradientes son simplemente el gradiente de salida,
        # con broadcasting si es necesario.
        
        # Para un prototipo simple, asumimos que los gradientes de entrada
        # son iguales al gradiente de salida (dL/da = dL/dc * 1).
        # La complejidad de broadcasting se maneja implícitamente por numpy
        # en la acumulación, pero la reducción de broadcasting se omite
        # por simplicidad.
        
        grads = []
        for parent in ctx.parents:
            # En una implementación real, se necesitaría lógica de reducción de broadcasting
            # aquí para que el gradiente tenga la forma correcta del padre.
            # Por ahora, devolvemos el gradiente de salida.
            grads.append(grad_output)
                
        return tuple(grads)

class Mul(Function):
    """
    Operación de multiplicación: c = a * b
    Gradientes: dL/da = dL/dc * b, dL/db = dL/dc * a
    """
    @staticmethod
    def forward(ctx, a, b):
        # Guardar a y b para el backward
        ctx.save_for_backward(a, b)
        
        if isinstance(b, Tensor):
            return a.data * b.data
        return a.data * b
        
    @staticmethod
    def backward(ctx, grad_output):
        a, b = ctx.saved_tensors
        
        # Manejar el caso de que b no sea un Tensor (ej. escalar)
        if isinstance(b, Tensor):
            grad_a = grad_output * b.data
            grad_b = grad_output * a.data
            return grad_a, grad_b
        else:
            # Si b es un escalar, solo hay gradiente para a
            grad_a = grad_output * b
            return (grad_a,) # Debe devolver una tupla

class Sum(Function):
    """
    Operación de suma de todos los elementos: b = sum(a)
    Gradiente: dL/da = dL/db * 1 (con la forma de a)
    """
    @staticmethod
    def forward(ctx, a):
        # Guardar la forma original para el backward
        ctx.save_for_backward(a.shape)
        return a.data.sum()
        
    @staticmethod
    def backward(ctx, grad_output):
        original_shape = ctx.saved_tensors[0]
        # El gradiente es el gradiente de salida (un escalar)
        # broadcasted a la forma original.
        # np.full crea un array de la forma original lleno con el valor del gradiente de salida.
        grad_a = np.full(original_shape, grad_output.item())
        return (grad_a,)

# --- Implementación de la Retropropagación (Backward) ---

def backward(tensor):
    """
    Inicia la retropropagación desde el tensor dado.
    """
    if not tensor.requires_grad:
        raise RuntimeError("El tensor no requiere gradiente.")
        
    # Inicializar el gradiente del tensor de salida
    if tensor.grad is None:
        tensor.grad = np.ones_like(tensor.data)
        
    # En una implementación real, se usaría una ordenación topológica.
    # Aquí, usamos una simplificación que funciona para grafos lineales simples.
    
    # Recolectar todas las funciones en el grafo
    functions_to_process = []
    
    def traverse(t):
        if t.grad_fn:
            # Añadir la función al inicio para simular orden inverso
            functions_to_process.insert(0, t)
            
            # Recorrer los padres (entradas de la función)
            cls, ctx = t.grad_fn
            for parent in ctx.parents:
                if isinstance(parent, Tensor) and parent.requires_grad:
                    traverse(parent)

    traverse(tensor)
    
    # Procesar las funciones en orden inverso
    for t in functions_to_process:
        cls, ctx = t.grad_fn
        
        # Calcular los gradientes de las entradas
        input_grads = cls.backward(ctx, t.grad)
        
        # Acumular los gradientes en los tensores de entrada
        for parent, grad in zip(ctx.parents, input_grads):
            if isinstance(parent, Tensor) and parent.requires_grad:
                if parent.grad is None:
                    parent.grad = grad
                else:
                    parent.grad += grad
