import numpy as np

class Tensor:
    """
    Clase Tensor, el núcleo de datos de MiniTorch Lite.
    Almacena datos multidimensionales y metadatos para el autograd.
    """
    
    def __init__(self, data, dtype=np.float32, requires_grad=False, grad_fn=None):
        # Asegurarse de que los datos son un array de NumPy
        if isinstance(data, (list, tuple)):
            data = np.array(data, dtype=dtype)
        elif not isinstance(data, np.ndarray):
            data = np.array([data], dtype=dtype)
        
        self.data = data
        self.dtype = dtype
        self.requires_grad = requires_grad
        
        # Atributos para el autograd
        self.grad = None
        self.grad_fn = grad_fn
        
    @property
    def shape(self):
        return self.data.shape

    @property
    def ndim(self):
        return self.data.ndim

    def __repr__(self):
        return f"Tensor(data={self.data.__repr__()}, shape={self.shape}, dtype={self.dtype}, requires_grad={self.requires_grad})"

    # --- Operaciones Básicas (Placeholder para Autograd) ---
    
    # Nota: Para el autograd, estas operaciones deben ser envueltas
    # en clases Function que construyan el grafo. Por ahora, solo
    # implementamos la funcionalidad básica de NumPy.
    
    def __add__(self, other):
        from .autograd import Add
        return Add.apply(self, other)

    def __mul__(self, other):
        from .autograd import Mul
        return Mul.apply(self, other)

    def sum(self):
        from .autograd import Sum
        return Sum.apply(self)

    # Implementar otras operaciones esenciales como:
    # __sub__, __truediv__, matmul, transpose, etc.
    
    # Ejemplo de una operación más compleja (matmul)
    def matmul(self, other):
        # Por ahora, matmul no soporta autograd, solo la operación directa
        if isinstance(other, Tensor):
            data = np.matmul(self.data, other.data)
        else:
            data = np.matmul(self.data, other)
        return Tensor(data, requires_grad=self.requires_grad or (isinstance(other, Tensor) and other.requires_grad))

# Función de conveniencia para crear tensores
def tensor(data, dtype=np.float32, requires_grad=False):
    return Tensor(data, dtype=dtype, requires_grad=requires_grad)

# Ejemplo de uso (para verificación)
if __name__ == '__main__':
    from .autograd import backward
    
    a = tensor([2.0, 3.0], requires_grad=True)
    b = tensor([1.0, 1.0], requires_grad=True)
    
    c = a * 2.0
    d = c + b
    y = d.sum()
    
    print("Tensor a:", a)
    print("Tensor b:", b)
    print("Tensor c (a * 2):", c)
    print("Tensor d (c + b):", d)
    print("Tensor y (d.sum()):", y)
    
    # Retropropagación
    backward(y)
    
    print("\n--- Gradientes ---")
    print("Gradiente de a (debería ser [2.0, 2.0]):", a.grad)
    print("Gradiente de b (debería ser [1.0, 1.0]):", b.grad)
    
    # Ejemplo con un escalar
    x = tensor(5.0, requires_grad=True)
    z = x * x
    backward(z)
    print("\nGradiente de x (z=x*x, dz/dx=2x, debería ser 10.0):", x.grad)
