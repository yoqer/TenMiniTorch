from .tensor import Tensor, tensor
import numpy as np

class Parameter(Tensor):
    """
    Un tipo especial de Tensor que se considera un parámetro del modelo.
    Siempre requiere gradiente.
    """
    def __init__(self, data, dtype=np.float32):
        super().__init__(data, dtype=dtype, requires_grad=True)

class Module:
    """
    Clase base para todos los módulos de redes neuronales.
    """
    def __init__(self):
        self._parameters = {}
        self._modules = {}

    def __call__(self, *args, **kwargs):
        return self.forward(*args, **kwargs)

    def forward(self, x):
        raise NotImplementedError

    def parameters(self):
        """
        Generador que itera sobre todos los parámetros del módulo y sus submódulos.
        """
        for name, param in self._parameters.items():
            yield param
        for name, module in self._modules.items():
            yield from module.parameters()

    def __setattr__(self, name, value):
        if isinstance(value, Parameter):
            self._parameters[name] = value
        elif isinstance(value, Module):
            self._modules[name] = value
        super().__setattr__(name, value)

    def zero_grad(self):
        """
        Pone a cero los gradientes de todos los parámetros.
        """
        for p in self.parameters():
            if p.grad is not None:
                p.grad = np.zeros_like(p.grad)

# --- Capas Básicas ---

class Linear(Module):
    """
    Capa lineal (fully connected).
    Salida = x @ W.T + b
    """
    def __init__(self, in_features, out_features):
        super().__init__()
        
        # Inicialización simple de Kaiming/He (uniforme)
        k = 1.0 / np.sqrt(in_features)
        
        # Pesos (W)
        self.weight = Parameter(
            np.random.uniform(-k, k, (out_features, in_features))
        )
        
        # Sesgos (b)
        self.bias = Parameter(
            np.random.uniform(-k, k, (out_features,))
        )

    def forward(self, x):
        # x @ W.T + b
        # Nota: La operación matmul en Tensor no tiene autograd implementado.
        # Usamos la implementación directa de Tensor que usa numpy.
        output = x.matmul(tensor(np.transpose(self.weight.data))) + self.bias
        return output

class ReLU(Module):
    """
    Función de activación ReLU.
    """
    def forward(self, x):
        # Asumiendo que una operación de comparación y máximo
        # se implementará en autograd.py (por ejemplo, Max)
        # Por ahora, solo la operación directa:
        return tensor(np.maximum(0, x.data), requires_grad=x.requires_grad)

class Sequential(Module):
    """
    Contenedor para apilar módulos secuencialmente.
    """
    def __init__(self, *args):
        super().__init__()
        for idx, module in enumerate(args):
            self._modules[str(idx)] = module

    def forward(self, x):
        for module in self._modules.values():
            x = module(x)
        return x

# --- Funciones de Pérdida (Loss) ---

class MSELoss(Module):
    """
    Error Cuadrático Medio (Mean Squared Error).
    """
    def forward(self, input, target):
        # loss = ((input - target)**2).mean()
        
        # Para el prototipo, solo la operación directa:
        diff = input.data - target.data
        loss_data = np.mean(diff ** 2)
        
        # El autograd debe ser manejado por las operaciones de Tensor
        # (sub, mul, sum, div).
        
        # **SOLUCIÓN TEMPORAL:** Devolver un Tensor con requires_grad=True
        # para que se pueda llamar a backward.
        
        # Para que el autograd funcione, necesitamos:
        # 1. Sub.apply(input, target)
        # 2. Mul.apply(diff, diff) (o Pow)
        # 3. Mean.apply(squared_diff) (o Sum y Div)
        
        # Por ahora, solo la estructura:
        return tensor(loss_data, requires_grad=input.requires_grad)

# --- Prueba de Módulos ---
if __name__ == '__main__':
    # Crear un modelo simple
    model = Sequential(
        Linear(in_features=2, out_features=3),
        ReLU(),
        Linear(in_features=3, out_features=1)
    )
    
    # Imprimir los parámetros
    print("--- Parámetros del Modelo ---")
    for i, p in enumerate(model.parameters()):
        print(f"Parámetro {i}: Shape={p.shape}, Requires_grad={p.requires_grad}")
        
    # Ejemplo de forward pass
    x = tensor([[1.0, 2.0]])
    y_pred = model(x)
    
    print("\n--- Forward Pass ---")
    print("Entrada (x):", x)
    print("Salida (y_pred):", y_pred)
    
    # Ejemplo de zero_grad
    model.zero_grad()
    print("\nGradientes después de zero_grad (deberían ser None):")
    for p in model.parameters():
        print(f"Gradiente: {p.grad}")
