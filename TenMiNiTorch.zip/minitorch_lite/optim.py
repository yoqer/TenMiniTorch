from .tensor import Tensor
import numpy as np

class SGD:
    """
    Optimizador de Descenso de Gradiente Estocástico (Stochastic Gradient Descent).
    """
    def __init__(self, parameters, lr=0.01):
        # Asegurarse de que los parámetros son una lista
        self.parameters = list(parameters)
        self.lr = lr

    def step(self):
        """
        Actualiza los parámetros usando el gradiente.
        p = p - lr * p.grad
        """
        for p in self.parameters:
            if p.grad is not None:
                # Actualización de los datos del tensor
                p.data -= self.lr * p.grad
                
    def zero_grad(self):
        """
        Pone a cero los gradientes de todos los parámetros.
        """
        for p in self.parameters:
            if p.grad is not None:
                p.grad = np.zeros_like(p.grad)

# --- Prueba de Optimizador ---
if __name__ == '__main__':
    # Nota: Esta prueba requiere que nn.py y tensor.py estén correctamente implementados.
    from .nn import Parameter
    from .tensor import tensor
    
    # Crear un parámetro de prueba
    p = Parameter(tensor([1.0, 2.0]).data)
    p.grad = np.array([0.5, 1.0])
    
    # Crear optimizador
    optimizer = SGD([p], lr=0.1)
    
    print("Parámetro inicial:", p.data)
    print("Gradiente:", p.grad)
    
    # Realizar un paso de optimización
    optimizer.step()
    
    print("Parámetro después de step:", p.data)
    
    # Verificar zero_grad
    optimizer.zero_grad()
    print("Gradiente después de zero_grad:", p.grad)
